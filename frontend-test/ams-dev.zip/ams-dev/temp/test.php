<?php

// echo __DIR__;

// echo "<br>";

// echo dirname(__FILE__);

// echo "<br>";



// $files = $_SERVER["DOCUMENT_ROOT"];



// echo $files;



require_once("../ams.php");

$JAMES = new AMS(0);

$JAMES->init_user_session();





print_r($_SESSION);



echo "<br><br>cookies<br><br>";



print_r($_COOKIE);

// echo "<br>".$JAMES->customEncrypt("_reset");

// echo "<br>".$JAMES->customEncrypt("_rUserId");





// echo "<br> last: ".$JAMES->user_exists("harshilramani.mscit20@vnsgu.ac.in");



?>